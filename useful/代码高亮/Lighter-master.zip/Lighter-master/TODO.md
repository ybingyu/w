To-do:
======

* MarkDown Fuel (Completed Oct 09)
* Global Style tags to prevent multiple inclusions. (Completed June 5th).
* Better white-space handling.
* Allow for multiple class names in the element. (Completed September 26).
* Copy to clipboard. (Completed September 28).
* Switch from JS based styles to Stylesheet based styles. (Completed October 5).
