ender.ender({
  audio5: require('audio5')
});